Pledge:
On my honor I have neither given nor received aid on this
exam.
Contents:
1. results t1.pdf : The required Results Report in required format. Extra 2 pages are included to report additional tests tried.
2. as1_psedoinverse.m : Matlab/Octave source code for Psedoinverse cases.
 Changing only A and O variables can give results for all cases. Documentation is in the code.
3. As1_ver11_grad_descent.m :Matlab/Octave source code for Gradient Descent cases.
Changing A , T and W variables gives results for all test cases. Documentation is in the code.
4. Test_train.m : Source code for Splitting data into Test and train data sets and run gradient descent algorithm.
The code also requires additional command lines to compare results. 

Note: If evaluator needs customized codes for test purpose, I would be glad to provide them. 
Thank you!
 